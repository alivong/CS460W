CREATE DATABASE  IF NOT EXISTS `hospital` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hospital`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hospital
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient_record`
--

DROP TABLE IF EXISTS `patient_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_record` (
  `patient_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT 'N/A',
  `address` varchar(45) DEFAULT 'N/A',
  `city` varchar(45) DEFAULT 'N/A',
  `state` varchar(45) DEFAULT 'N/A',
  `zip_code` varchar(45) DEFAULT 'N/A',
  `dob` varchar(45) DEFAULT 'N/A',
  `ssn` varchar(45) DEFAULT 'N/A',
  `number` varchar(45) DEFAULT 'N/A',
  `email` varchar(45) DEFAULT 'N/A',
  `height_feet` varchar(45) DEFAULT 'N/A',
  `height_inches` varchar(45) DEFAULT 'N/A',
  `weight` varchar(45) DEFAULT 'N/A',
  `blood_type` varchar(45) DEFAULT 'N/A',
  `gender` varchar(45) DEFAULT 'N/A',
  `race` varchar(45) DEFAULT 'N/A',
  `religion` varchar(45) DEFAULT 'N/A',
  `emergency_name` varchar(45) DEFAULT 'N/A',
  `emergency_number` varchar(45) DEFAULT 'N/A',
  `primary_physician` varchar(45) DEFAULT 'N/A',
  `health_insurance` varchar(45) DEFAULT 'N/A',
  `covid_vaccine_name` varchar(45) DEFAULT 'N/A',
  `covid_vaccine_date_1` varchar(45) DEFAULT 'N/A',
  `covid_vaccine_date_2` varchar(45) DEFAULT 'N/A',
  `covid_vaccine_booster_date` varchar(45) DEFAULT 'N/A',
  `sexually_active` varchar(45) DEFAULT 'N/A',
  `pregnant` varchar(45) DEFAULT 'N/A',
  `allergies` varchar(300) DEFAULT 'N/A',
  `previous_medical_conditions` varchar(400) DEFAULT 'N/A',
  `previous_medication` varchar(300) DEFAULT 'N/A',
  `symptoms` varchar(400) DEFAULT 'N/A',
  `check_in_date` varchar(45) DEFAULT 'N/A',
  `body_temp` varchar(45) DEFAULT 'N/A',
  `blood_pressure` varchar(45) DEFAULT 'N/A',
  `admitted` varchar(45) DEFAULT 'N/A',
  `assigned_physician` varchar(45) DEFAULT 'N/A',
  `nights_stayed` varchar(45) DEFAULT 'N/A',
  `nurse_notes` varchar(800) DEFAULT 'N/A',
  `discharge_submitted` varchar(45) DEFAULT 'no',
  `diagnosis` varchar(45) DEFAULT 'N/A',
  `tests` varchar(800) DEFAULT 'N/A',
  `medication` varchar(45) DEFAULT 'N/A',
  `doctor_notes` varchar(800) DEFAULT 'N/A',
  `total_bill` double DEFAULT '0',
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_record`
--

LOCK TABLES `patient_record` WRITE;
/*!40000 ALTER TABLE `patient_record` DISABLE KEYS */;
INSERT INTO `patient_record` VALUES (1,'John Smith','West Hartford, CT 06117',NULL,NULL,NULL,'05/12/1995',NULL,'860-472-1282','jsmith@hotmail.com','6',NULL,'170','A+',NULL,NULL,NULL,'Robert Flench','860-124-4912',NULL,NULL,'Pfizer','04/05/2021','05/07/2021','12/15/2021',NULL,'No','N/A','Arthritis,Asthma','N/A','headache, fever',NULL,'98','130/80',NULL,'N/A',NULL,'bunch of notes','yes','Covid-19','Liver function test,Renal function test,X-rays,CT scans,Urinary Test,Stool Test,Intramuscular injection (IM),Intravascular injection (IV),','Acetaminophen','updated notes mmoree',5),(9,'test name','some address','sm city','CT','02312','02/23/1994','224356902','2491293592','testnameem@gmail.com','5','11','150','O+','male','Hispanic or Latino','smreligion','emergency name','2343561241','phys name','cigna','Moderna','04/20/2021','05/20/2021','12/14/2021','Yes','No','no','asthma, hypertension','no','headache and cough','03/23/2026','98','140/80','Yes','Dr. Fred','5','no notes for now ','yes','Asthma','White blood cell,Renal function test,X-rays,CT scans,Urinary Test,Stool Test,P.O (Per Os)','Albuterol','More notes ',8983),(10,'N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','no','N/A','N/A','N/A','N/A',0);
/*!40000 ALTER TABLE `patient_record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-21  2:59:15
