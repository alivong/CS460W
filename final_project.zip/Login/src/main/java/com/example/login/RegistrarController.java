package com.example.login;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class RegistrarController implements Initializable{
    //ones ending in 1 are the similar fields that are used in create record
    public Button update_button;
    public TextField name;
    public TextField address;
    public TextField state;
    public TextField zip;
    public TextField city;
    public TextField number;
    public TextField email;
    public TextField dob;
    public TextField ssn;
    public ComboBox covid_name;
    public ComboBox sexually_active;
    public ComboBox race;
    public ComboBox bloodtype;
    public TextField height_feet;
    public TextField height_inches;
    public TextField weight;
    public TextField religion;
    public TextField emergency_name;
    public TextField emergency_number;
    public TextField gender;
    public TextField primary_p;
    public TextField health_insurance;
    public TextField second_shot;
    public TextField booster;
    public TextField first_shot;
    public ComboBox pregnant;
    public TextArea allergies;
    public TextArea previous_medical_conditions;
    public TextArea previous_medication;
    public TextArea symptoms;
    public TextField checkin_date;
    public Button id_search;
    public TextField patient_id;
    public TextField name1;
    public TextField address1;
    public TextField state1;
    public TextField zip1;
    public TextField city1;
    public TextField number1;
    public TextField email1;
    public TextField dob1;
    public TextField ssn1;
    public ComboBox covid_name1;
    public ComboBox sexually_active1;
    public ComboBox race1;
    public ComboBox bloodtype1;
    public TextField height_feet1;
    public TextField height_inches1;
    public TextField weight1;
    public TextField religion1;
    public TextField emergency_name1;
    public TextField emergency_number1;
    public TextField gender1;
    public TextField primary_p1;
    public TextField health_insurance1;
    public TextField second_shot1;
    public TextField booster1;
    public TextField first_shot1;
    public ComboBox pregnant1;
    public TextArea allergies1;
    public TextArea previous_medical_conditions1;
    public TextArea previous_medication1;
    public TextArea symptoms1;
    public Button create_button;
    public Label label_no_id;
    public Button logout_button;
    public Label user_name;


    public void logout(javafx.event.ActionEvent actionEvent) throws Exception{
        Parent root;
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout_button.getScene().getWindow();
        window.setScene(new Scene(root, 800,600));
    }

    public void search_button(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        if (patient_id.getText().isEmpty()) {
            label_no_id.setText("The field cannot be left blank. You must enter an ID");
        }

        else {
            String connectQuery = "SELECT * FROM patient_record WHERE patient_id = " + patient_id.getText() + ";";
            label_no_id.setText("");
            try {
                Statement statement = connect.createStatement();
                ResultSet queryRes = statement.executeQuery(connectQuery);

                if(!queryRes.isBeforeFirst()){
                    label_no_id.setText("No patient with this ID found");
                }
                else {
                    while (queryRes.next()) {
                        name.setText(queryRes.getString("name"));
                        address.setText(queryRes.getString("address"));
                        city.setText(queryRes.getString("city"));
                        state.setText(queryRes.getString("state"));
                        zip.setText(queryRes.getString("zip_code"));
                        dob.setText(queryRes.getString("dob"));
                        ssn.setText(queryRes.getString("ssn"));
                        number.setText(queryRes.getString("number"));
                        email.setText(queryRes.getString("email"));
                        height_feet.setText(queryRes.getString("height_feet"));
                        height_inches.setText(queryRes.getString("height_inches"));
                        weight.setText(queryRes.getString("weight"));
                        gender.setText(queryRes.getString("gender"));
                        religion.setText(queryRes.getString("religion"));
                        emergency_name.setText(queryRes.getString("emergency_name"));
                        emergency_number.setText(queryRes.getString("emergency_number"));
                        primary_p.setText(queryRes.getString("primary_physician"));
                        health_insurance.setText(queryRes.getString("health_insurance"));
                        first_shot.setText(queryRes.getString("covid_vaccine_date_1"));
                        second_shot.setText(queryRes.getString("covid_vaccine_date_2"));
                        booster.setText(queryRes.getString("covid_vaccine_booster_date"));
                        allergies.setText(queryRes.getString("allergies"));
                        previous_medical_conditions.setText(queryRes.getString("previous_medical_conditions"));
                        previous_medication.setText(queryRes.getString("previous_medication"));
                        symptoms.setText(queryRes.getString("symptoms"));
                        covid_name.setValue(queryRes.getString("covid_vaccine_name"));
                        sexually_active.setValue(queryRes.getString("sexually_active"));
                        race.setValue(queryRes.getString("race"));
                        bloodtype.setValue(queryRes.getString("blood_type"));
                        pregnant.setValue(queryRes.getString("pregnant"));

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        covid_name.getItems().addAll("Pfizer", "Moderna", "J & J");
        sexually_active.getItems().addAll("Yes", "No");
        race.getItems().addAll("White", "Black or African American", "Hispanic or Latino", "Asian", "Native Hawaiian or Other Pacific Islander", "American Indian or Alaska Native");
        bloodtype.getItems().addAll("O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+");
        pregnant.getItems().addAll("Yes", "No");
        covid_name1.getItems().addAll("Pfizer", "Moderna", "J & J");
        sexually_active1.getItems().addAll("Yes", "No");
        race1.getItems().addAll("White", "Black or African American", "Hispanic or Latino", "Asian", "Native Hawaiian or Other Pacific Islander", "American Indian or Alaska Native");
        bloodtype1.getItems().addAll("O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+");
        pregnant1.getItems().addAll("Yes", "No");
        String user_name_query = "SELECT name FROM user_accounts WHERE user_id = " + LoginController.userID  + ";";
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(user_name_query);

            queryRes.next();

            user_name.setText(queryRes.getString("name"));

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void update_button(javafx.event.ActionEvent actionEvent) {

        if (patient_id.getText().isEmpty()) {
            return;
        }

        String update_query = "UPDATE patient_record SET name = '" + name.getText() +  "', address = '" + address.getText()
                + "', city = '" + city.getText()  + "', state = '" + state.getText()
                + "', zip_code = '" + zip.getText()  + "', dob = '" + dob.getText()
                + "', ssn = '" + ssn.getText()  + "', number = '" + number.getText()
                + "', email = '" + email.getText()  + "', height_feet = '" + height_feet.getText() + "', height_inches = '" + height_inches.getText()
                + "', weight = '" + weight.getText()  + "', gender = '" + gender.getText()
                + "', religion = '" + religion.getText()  + "', emergency_name = '" + emergency_name.getText()
                + "', emergency_number = '" + emergency_number.getText()  + "', primary_physician = '" + primary_p.getText()
                + "', health_insurance = '" + health_insurance.getText()  + "', covid_vaccine_date_1 = '" + first_shot.getText()
                + "', covid_vaccine_date_2 = '" + second_shot.getText()  + "', covid_vaccine_booster_date = '" + booster.getText()
                + "', allergies = '" + allergies.getText()  + "', previous_medical_conditions = '" + previous_medical_conditions.getText()
                + "', previous_medication = '" + previous_medication.getText()  + "', symptoms = '" + symptoms.getText()
                + "', covid_vaccine_name = '" + covid_name.getValue()  + "', sexually_active = '" + sexually_active.getValue()
                + "', race = '" + race.getValue() + "', blood_type = '" + bloodtype.getValue()
                + "', pregnant = '" + pregnant.getValue() + "' WHERE patient_id = " + patient_id.getText() + ";";

        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement st = connect.createStatement();
            st.executeUpdate(update_query);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            //alert.setHeaderText("This is header text.");
            alert.setContentText("Successfully updated the information for patient with ID: " + patient_id.getText());
            alert.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void create_button(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        String create_query = "INSERT INTO patient_record(name, address, city, state, zip_code, dob, ssn, number" +
                ", email, height_feet, height_inches, weight, gender, religion, emergency_name, emergency_number, primary_physician, health_insurance, covid_vaccine_date_1," +
                " covid_vaccine_date_2, covid_vaccine_booster_date, allergies, previous_medical_conditions, previous_medication, symptoms, covid_vaccine_name, " +
                "sexually_active, race, blood_type, pregnant, check_in_date) VALUES ('"+ name1.getText()  +"', '"+ address1.getText() +"'," +
                " '"+ city1.getText() +"', '"+ state1.getText() +"', '"+ zip1.getText() +"', '"+ dob1.getText() +"', '"+ ssn1.getText() +"'," +
                " '"+ number1.getText() +"', '"+ email1.getText() +"', '"+ height_feet1.getText() +"', '"+ height_inches1.getText() +"', '"+ weight1.getText() +"', '"+ gender1.getText() +"'," +
                " '"+ religion1.getText() +"', '"+ emergency_name1.getText() +"', '"+ emergency_number1.getText() +"', '"+ primary_p1.getText() +"'," +
                " '"+ health_insurance1.getText() +"', '"+ first_shot1.getText() +"', '"+ second_shot1.getText() +"', '"+ booster1.getText() +"'," +
                " '"+allergies1.getText()  +"', '"+ previous_medical_conditions1.getText() +"', '"+ previous_medication1.getText() +"'," +
                " '"+ symptoms1.getText() +"', '"+ covid_name1.getValue() +"', '"+ sexually_active1.getValue() +"', '"+ race1.getValue() +"'," +
                " '"+ bloodtype1.getValue() +"', '"+ pregnant1.getValue() +"', '"+ checkin_date.getText() +"');";


        try {
            Statement st = connect.createStatement();
            st.executeUpdate(create_query);


            String get_id_query = "SELECT * FROM patient_record ORDER BY patient_id DESC LIMIT 1;";
            try {
                Statement statement = connect.createStatement();
                ResultSet queryRes = statement.executeQuery(get_id_query);
                queryRes.next();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText(null);
                alert.setContentText("Patient record successfully created and given a patient ID: " + queryRes.getString("patient_id"));
                alert.showAndWait();

            } catch (Exception e){
                e.printStackTrace();

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Success");
                alert.setHeaderText(null);
                alert.setContentText("There was an issue creating patient record");
                alert.showAndWait();

            }

        } catch (Exception e) {
            e.printStackTrace();

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("There was an issue creating patient record");
            alert.showAndWait();

        }


    }

}
