package com.example.login;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class NurseController implements Initializable {
    public TextField name;
    public TextField dob;
    public ComboBox covid_name;
    public ComboBox sexually_active;
    public ComboBox race;
    public ComboBox bloodtype;
    public TextField weight;
    public TextField religion;
    public TextField gender;
    public TextField primary_p;
    public TextField health_insurance;
    public TextField second_shot;
    public TextField booster;
    public TextField first_shot;
    public ComboBox pregnant;
    public TextArea allergies;
    public TextArea previous_medical_conditions;
    public TextArea previous_medication;
    public TextArea symptoms;
    public Button id_search;
    public TextField patient_id;
    public Button update_button;
    public Label label_no_id;
    public TextField height_feet;
    public TextField height_inches;
    public TextField body_temp;
    public TextField blood_pressure;
    public TextField nights_stayed;
    public TextField assigned_p;
    public ComboBox admitted;
    public TextArea notes;
    public TextField checkin_date;
    public Button logout_button;
    public Label user_name;

    public void logout(javafx.event.ActionEvent actionEvent) throws Exception{
        Parent root;
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout_button.getScene().getWindow();
        window.setScene(new Scene(root, 800,600));
    }

    public void search_button(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        if (patient_id.getText().isEmpty()) {
            label_no_id.setText("The field cannot be left blank. You must enter an ID");
        }

        else {
            String connectQuery = "SELECT * FROM patient_record WHERE patient_id = " + patient_id.getText() + ";";
            label_no_id.setText("");
            try {
                Statement statement = connect.createStatement();
                ResultSet queryRes = statement.executeQuery(connectQuery);

                if(!queryRes.isBeforeFirst()){
                    label_no_id.setText("No patient with this ID found");
                }
                else {
                    while (queryRes.next()) {
                        name.setText(queryRes.getString("name"));
                        dob.setText(queryRes.getString("dob"));
                        assigned_p.setText(queryRes.getString("assigned_physician"));
                        body_temp.setText(queryRes.getString("body_temp"));
                        blood_pressure.setText(queryRes.getString("blood_pressure"));
                        nights_stayed.setText(queryRes.getString("nights_stayed"));
                        height_feet.setText(queryRes.getString("height_feet"));
                        height_inches.setText(queryRes.getString("height_inches"));
                        weight.setText(queryRes.getString("weight"));
                        gender.setText(queryRes.getString("gender"));
                        religion.setText(queryRes.getString("religion"));
                        primary_p.setText(queryRes.getString("primary_physician"));
                        health_insurance.setText(queryRes.getString("health_insurance"));
                        first_shot.setText(queryRes.getString("covid_vaccine_date_1"));
                        second_shot.setText(queryRes.getString("covid_vaccine_date_2"));
                        checkin_date.setText(queryRes.getString("check_in_date"));
                        booster.setText(queryRes.getString("covid_vaccine_booster_date"));
                        allergies.setText(queryRes.getString("allergies"));
                        previous_medical_conditions.setText(queryRes.getString("previous_medical_conditions"));
                        previous_medication.setText(queryRes.getString("previous_medication"));
                        symptoms.setText(queryRes.getString("symptoms"));
                        notes.setText(queryRes.getString("nurse_notes"));
                        covid_name.setValue(queryRes.getString("covid_vaccine_name"));
                        sexually_active.setValue(queryRes.getString("sexually_active"));
                        race.setValue(queryRes.getString("race"));
                        bloodtype.setValue(queryRes.getString("blood_type"));
                        pregnant.setValue(queryRes.getString("pregnant"));
                        admitted.setValue(queryRes.getString("admitted"));

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        covid_name.getItems().addAll("Pfizer", "Moderna", "J & J");
        sexually_active.getItems().addAll("Yes", "No");
        race.getItems().addAll("White", "Black or African American", "Hispanic or Latino", "Asian", "Native Hawaiian or Other Pacific Islander", "American Indian or Alaska Native");
        bloodtype.getItems().addAll("O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+");
        pregnant.getItems().addAll("Yes", "No");
        admitted.getItems().addAll("Yes", "No");
        String user_name_query = "SELECT name FROM user_accounts WHERE user_id = " + LoginController.userID  + ";";
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(user_name_query);

            queryRes.next();

            user_name.setText(queryRes.getString("name"));

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void update_button(javafx.event.ActionEvent actionEvent) {

        if (patient_id.getText().isEmpty()) {
            return;
        }

        String update_query = "UPDATE patient_record SET  assigned_physician = '" + assigned_p.getText()
                + "', body_temp = '" + body_temp.getText()  + "', blood_pressure = '" + blood_pressure.getText()
                + "', admitted = '" + admitted.getValue()  + "', nights_stayed = '" + nights_stayed.getText()
                + "', height_feet = '" + height_feet.getText() + "', height_inches = '" + height_inches.getText()
                + "', weight = '" + weight.getText()  + "', nurse_notes = '" + notes.getText()
                + "' WHERE patient_id = " + patient_id.getText() + ";";

        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement st = connect.createStatement();
            st.executeUpdate(update_query);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            //alert.setHeaderText("This is header text.");
            alert.setContentText("Successfully updated the information for patient with ID: " + patient_id.getText());
            alert.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
