package com.example.login;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class PatientController implements Initializable {
    public TextField name1;
    public TextField address1;
    public TextField state1;
    public TextField zip1;
    public TextField city1;
    public TextField number1;
    public TextField email1;
    public TextField dob1;
    public TextField ssn1;
    public TextField covid_name1;
    public TextField sexually_active1;
    public TextField race1;
    public TextField bloodtype1;
    public TextField height_feet1;
    public TextField weight1;
    public TextField religion1;
    public TextField emergency_name1;
    public TextField emergency_number1;
    public TextField gender1;
    public TextField primary_p1;
    public TextField health_insurance1;
    public TextField second_shot1;
    public TextField booster1;
    public TextField first_shot1;
    public TextField pregnant1;
    public TextArea allergies1;
    public TextArea previous_medical_conditions1;
    public TextArea previous_medication1;
    public TextArea symptoms1;
    public TextField checkin_date;
    public TextField height_inches1;
    public Button view_discharge_button;
    public TextArea services_label_discharge;
    public TextField diagnosis;
    public TextField medication;
    public TextArea doctor_notes;
    public TextField nights_stayed;
    public TextField totalCostLabel;
    public Label patient_id_bill;
    public Label patient_id_discharge;
    public Label patient_id_personal;
    public Text tests_label;
    public Text diagnosis_label;
    public Text notes_label;
    public Text medication_label;
    public Text nights_label;
    public TextArea services_label;
    public TextArea cost_label_1;
    public Text services_label_1;
    public Text total_label;
    public Text charge_label;
    public Text cost_label;
    public Text nights_charge;
    public TextField default_value;
    public Button logout_button;
    public Label user_name;


    public void logout(javafx.event.ActionEvent actionEvent) throws Exception{
        Parent root;
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout_button.getScene().getWindow();
        window.setScene(new Scene(root, 800,600));
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {

        String user_name_query = "SELECT name FROM user_accounts WHERE user_id = " + LoginController.userID  + ";";
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(user_name_query);

            queryRes.next();

            user_name.setText(queryRes.getString("name"));

        }catch(Exception e){
            e.printStackTrace();
        }

        patient_id_personal.setText(LoginController.userID);
        patient_id_discharge.setText(LoginController.userID);
        patient_id_bill.setText(LoginController.userID);


        diagnosis_label.setOpacity(0);
        medication_label.setOpacity(0);
        tests_label.setOpacity(0);
        notes_label.setOpacity(0);
        diagnosis.setOpacity(0);
        medication.setOpacity(0);
        services_label_discharge.setOpacity(0);
        doctor_notes.setOpacity(0);
        diagnosis.setStyle("-fx-control-inner-background: #ffffff;");
        medication.setStyle("-fx-control-inner-background: #ffffff;");
        services_label_discharge.setStyle("-fx-control-inner-background: #ffffff;");
        doctor_notes.setStyle("-fx-control-inner-background: #ffffff;");

        services_label_1.setOpacity(0);
        cost_label.setOpacity(0);
        charge_label.setOpacity(0);
        nights_label.setOpacity(0);
        total_label.setOpacity(0);
        services_label.setOpacity(0);
        cost_label_1.setOpacity(0);
        default_value.setOpacity(0);
        nights_stayed.setOpacity(0);
        nights_charge.setOpacity(0);
        totalCostLabel.setOpacity(0);
        services_label.setStyle("-fx-control-inner-background: #ffffff;");
        cost_label_1.setStyle("-fx-control-inner-background: #ffffff;");
        default_value.setStyle("-fx-control-inner-background: #ffffff;");
        nights_stayed.setStyle("-fx-control-inner-background: #ffffff;");
        totalCostLabel.setStyle("-fx-control-inner-background: #ffffff;");

        String connectQuery = "SELECT * FROM patient_record WHERE patient_id = " + LoginController.userID + ";";
        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(connectQuery);

            while (queryRes.next()) {
                name1.setText(queryRes.getString("name"));
                address1.setText(queryRes.getString("address"));
                city1.setText(queryRes.getString("city"));
                state1.setText(queryRes.getString("state"));
                zip1.setText(queryRes.getString("zip_code"));
                dob1.setText(queryRes.getString("dob"));
                ssn1.setText(queryRes.getString("ssn"));
                number1.setText(queryRes.getString("number"));
                email1.setText(queryRes.getString("email"));
                height_feet1.setText(queryRes.getString("height_feet"));
                height_inches1.setText(queryRes.getString("height_inches"));
                weight1.setText(queryRes.getString("weight"));
                gender1.setText(queryRes.getString("gender"));
                religion1.setText(queryRes.getString("religion"));
                emergency_name1.setText(queryRes.getString("emergency_name"));
                emergency_number1.setText(queryRes.getString("emergency_number"));
                primary_p1.setText(queryRes.getString("primary_physician"));
                health_insurance1.setText(queryRes.getString("health_insurance"));
                first_shot1.setText(queryRes.getString("covid_vaccine_date_1"));
                second_shot1.setText(queryRes.getString("covid_vaccine_date_2"));
                booster1.setText(queryRes.getString("covid_vaccine_booster_date"));
                allergies1.setText(queryRes.getString("allergies"));
                previous_medical_conditions1.setText(queryRes.getString("previous_medical_conditions"));
                previous_medication1.setText(queryRes.getString("previous_medication"));
                symptoms1.setText(queryRes.getString("symptoms"));
                covid_name1.setText(queryRes.getString("covid_vaccine_name"));
                sexually_active1.setText(queryRes.getString("sexually_active"));
                race1.setText(queryRes.getString("race"));
                bloodtype1.setText(queryRes.getString("blood_type"));
                pregnant1.setText(queryRes.getString("pregnant"));
                checkin_date.setText(queryRes.getString("check_in_date"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void view_discharge_info(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        String connectQuery = "SELECT discharge_submitted FROM patient_record WHERE patient_id = " + LoginController.userID + ";";
        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(connectQuery);

            queryRes.next();

            if (queryRes.getString("discharge_submitted").equals("no")) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Discharge Info has still not been submitted by your doctor");
                alert.showAndWait();
            } else if (queryRes.getString("discharge_submitted").equals("yes")) {
                diagnosis_label.setOpacity(1);
                medication_label.setOpacity(1);
                tests_label.setOpacity(1);
                notes_label.setOpacity(1);
                diagnosis.setOpacity(1);
                medication.setOpacity(1);
                services_label_discharge.setOpacity(1);
                doctor_notes.setOpacity(1);
                diagnosis.setStyle("-fx-control-inner-background: #D0D0D2;");
                medication.setStyle("-fx-control-inner-background: #D0D0D2;");
                services_label_discharge.setStyle("-fx-control-inner-background: #D0D0D2;");
                doctor_notes.setStyle("-fx-control-inner-background: #D0D0D2;");

                String discharge_query = "SELECT * FROM patient_record WHERE patient_id = " + LoginController.userID + ";";
                ResultSet discharge_query_res = statement.executeQuery(discharge_query);

                while (discharge_query_res.next()) {
                    diagnosis.setText(discharge_query_res.getString("diagnosis"));
                    medication.setText(discharge_query_res.getString("medication"));
                    doctor_notes.setText(discharge_query_res.getString("doctor_notes"));
                    if (discharge_query_res.getString("tests").isEmpty() == false && discharge_query_res.getString("tests").equals("N/A") == false) {
                        String fulllist = "";
                        String[] servicess = new String[]{};
                        servicess = discharge_query_res.getString("tests").split(",");

                        for (String ser : servicess) {
                            fulllist += ser + "\n";
                        }
                        services_label_discharge.setText(fulllist);
                    } else {
                        services_label_discharge.setText("");
                    }
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void view_bill(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        String bill_check = "SELECT total_bill FROM patient_record WHERE patient_id = " + LoginController.userID + ";";
        double total_cost = 0;
        try {
            Statement statement = connect.createStatement();
            ResultSet bill_c = statement.executeQuery(bill_check);

            bill_c.next();
            total_cost = bill_c.getDouble("total_bill");
        } catch (Exception e) {
            e.printStackTrace();
        }

            if (total_cost== 0) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("No bill posted yet.");
                alert.showAndWait();
            }
            else{

                String get_info = "SELECT * FROM patient_record WHERE patient_id = " + LoginController.userID + ";";
                try{
                    Statement statement = connect.createStatement();
                    ResultSet queryRes = statement.executeQuery(get_info);

                    String fulllist = "";
                    String costs = "";
                    String[] servicess = new String[]{};
                    String medication = "";
                    while (queryRes.next()) {
                        services_label_1.setOpacity(1);
                        cost_label.setOpacity(1);
                        charge_label.setOpacity(1);
                        nights_label.setOpacity(1);
                        total_label.setOpacity(1);
                        services_label.setOpacity(1);
                        cost_label_1.setOpacity(1);
                        default_value.setOpacity(1);
                        nights_stayed.setOpacity(1);
                        nights_charge.setOpacity(1);
                        totalCostLabel.setOpacity(1);
                        services_label.setStyle("-fx-control-inner-background: #D0D0D2;");
                        cost_label_1.setStyle("-fx-control-inner-background: #D0D0D2;");
                        default_value.setStyle("-fx-control-inner-background: #D0D0D2;");
                        nights_stayed.setStyle("-fx-control-inner-background: #D0D0D2;");
                        totalCostLabel.setStyle("-fx-control-inner-background: #D0D0D2;");
                        nights_stayed.setText(queryRes.getString("nights_stayed"));
                        if (queryRes.getString("tests").isEmpty() == false && queryRes.getString("tests").equals("N/A") == false) {
                            servicess = queryRes.getString("tests").split(",");

                            for (String ser : servicess) {
                                fulllist += ser + "\n";
                            }

                            fulllist += queryRes.getString("medication");
                            services_label.setText(fulllist);

                            medication = queryRes.getString("medication");
                        } else {
                            services_label.setText("");
                            cost_label_1.setText("");
                            totalCostLabel.setText("");
                            servicess = null;

                        }
                    }
                    if (servicess != null) {
                        for (String ser : servicess) {
                            String getCost = "SELECT cost FROM service_cost WHERE service = '" + ser + "';";
                            ResultSet cost_query = statement.executeQuery(getCost);
                            cost_query.next();
                            costs += String.valueOf(cost_query.getDouble("cost")) + "\n";
                        }

                        String getCost = "SELECT cost FROM service_cost WHERE service = '" + medication + "';";
                        ResultSet cost_query = statement.executeQuery(getCost);
                        cost_query.next();
                        costs += String.valueOf(cost_query.getDouble("cost")) + "\n";
                        cost_label_1.setText(costs);
                        totalCostLabel.setText(String.valueOf(total_cost));
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }





    }
}












