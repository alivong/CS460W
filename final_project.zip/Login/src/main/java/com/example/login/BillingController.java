package com.example.login;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.Parent;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class BillingController implements Initializable {

    public Button id_search;
    public TextField patient_id;
    public Label label_no_id;
    public Label services_label;
    public Label cost_label;
    public Label totalCostLabel;
    public TextField nights_stayed;
    public TextField assigned_p;
    public TextField name;
    public TextField dob;
    public TextField health_insurance;
    public TextField address;
    public TextField state;
    public TextField zip;
    public TextField city;
    public TextField number;
    public TextField email;
    public TextField ssn;
    public Button submit_bill_button;
    public Button logout_button;
    public Label user_name;


    private Text serviceListText;

    static double totalServiceCost;
    public static double totalCost;

    public void logout(javafx.event.ActionEvent actionEvent) throws Exception{
        Parent root;
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout_button.getScene().getWindow();
        window.setScene(new Scene(root, 800,600));
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String user_name_query = "SELECT name FROM user_accounts WHERE user_id = " + LoginController.userID  + ";";
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(user_name_query);

            queryRes.next();

            user_name.setText(queryRes.getString("name"));

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void search_button(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        if (patient_id.getText().isEmpty()) {
            label_no_id.setText("The field cannot be left blank. You must enter an ID");
        } else {
            String connectQuery = "SELECT * FROM patient_record WHERE patient_id = " + patient_id.getText() + ";";
            label_no_id.setText("");
            try {
                Statement statement = connect.createStatement();
                ResultSet queryRes = statement.executeQuery(connectQuery);

                if (!queryRes.isBeforeFirst()) {
                    label_no_id.setText("No patient with this ID found");
                } else {
                    String fulllist = "";
                    String costs = "";
                    String[] servicess = new String[]{};
                    String medication = "";
                    int total_nights_cost = 0;
                    while (queryRes.next()) {
                        name.setText(queryRes.getString("name"));
                        address.setText(queryRes.getString("address"));
                        city.setText(queryRes.getString("city"));
                        state.setText(queryRes.getString("state"));
                        zip.setText(queryRes.getString("zip_code"));
                        dob.setText(queryRes.getString("dob"));
                        ssn.setText(queryRes.getString("ssn"));
                        number.setText(queryRes.getString("number"));
                        email.setText(queryRes.getString("email"));
                        assigned_p.setText(queryRes.getString("assigned_physician"));
                        health_insurance.setText(queryRes.getString("health_insurance"));
                        nights_stayed.setText(queryRes.getString("nights_stayed"));
                        if (queryRes.getString("tests").isEmpty() == false && queryRes.getString("tests").equals("N/A") == false) {
                            servicess = queryRes.getString("tests").split(",");

                            for (String ser : servicess) {
                                fulllist += ser + "\n";
                            }

                            fulllist += queryRes.getString("medication");
                            services_label.setText(fulllist);

                            medication = queryRes.getString("medication");
                        } else {
                            services_label.setText("");
                            cost_label.setText("");
                            totalCostLabel.setText("");
                            nights_stayed.setText("0");
                            totalCost = 0;
                            servicess = null;

                        }
                    }
                    if (servicess != null) {
                        for (String ser : servicess) {
                            String getCost = "SELECT cost FROM service_cost WHERE service = '" + ser + "';";
                            ResultSet cost_query = statement.executeQuery(getCost);
                            cost_query.next();
                            costs += String.valueOf(cost_query.getDouble("cost")) + "\n";
                            totalCost += cost_query.getDouble("cost");
                        }

                        String getCost = "SELECT cost FROM service_cost WHERE service = '" + medication + "';";
                        ResultSet cost_query = statement.executeQuery(getCost);
                        cost_query.next();
                        costs += String.valueOf(cost_query.getDouble("cost")) + "\n";
                        totalCost += cost_query.getDouble("cost");
                        cost_label.setText(costs);
                        total_nights_cost = 1500 * Integer.parseInt(nights_stayed.getText());
                        totalCost += total_nights_cost + 500;
                        totalCostLabel.setText(String.valueOf(totalCost));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void submit_bill(javafx.event.ActionEvent actionEvent) {

        if (patient_id.getText().isEmpty()) {
            return;
        }

        if (totalCost == 0) {
            return;
        }
        String submit_bill_query = "UPDATE patient_record SET total_bill = " + totalCost + " WHERE patient_id = " + patient_id.getText() + ";";

        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement st = connect.createStatement();
            st.executeUpdate(submit_bill_query);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Successfully submitted bill for patient with ID: " + patient_id.getText());
            alert.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
