package com.example.login;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class DoctorController implements Initializable {


    public TextField weight;
    public TextField height_feet;
    public TextField height_inches;
    public TextField body_temp;
    public TextField blood_pressure;
    public TextField nights_stayed;
    public TextField assigned_p;
    public ComboBox admitted;
    public TextField name;
    public TextField dob;
    public ComboBox covid_name;
    public ComboBox sexually_active;
    public ComboBox race;
    public ComboBox bloodtype;
    public TextField religion;
    public TextField gender;
    public TextField primary_p;
    public TextField health_insurance;
    public TextField second_shot;
    public TextField booster;
    public TextField first_shot;
    public ComboBox pregnant;
    public TextArea allergies;
    public TextArea previous_medical_conditions;
    public TextArea previous_medication;
    public TextArea symptoms;
    public Button id_search;
    public TextField patient_id;
    public Button update_button1;
    public Label label_no_id;
    public TextArea notes;
    public TextField checkin_date;
    public ComboBox diagnosis_box;
    public ComboBox medication_box;
    public CheckBox red_blood_cell_box;
    public CheckBox White_blood_cell_box;
    public CheckBox Liver_function_test_box;
    public CheckBox Renal_function_test_box;
    public CheckBox Electrolyte_test_box;
    public CheckBox X_rays_box;
    public CheckBox Urinary_Test_box;
    public CheckBox MRI_scans_box;
    public CheckBox CT_scans_box;
    public CheckBox Stool_Test_box;
    public CheckBox Intramuscular_injection_box;
    public CheckBox P_box;
    public CheckBox Subcutaneous_injection_box;
    public CheckBox Intravascular_injection_box;
    public TextArea doctor_notes;
    public Button add_button;
    public TextField patient_id1;
    public ComboBox diagnosis_box1;
    public ComboBox medication_box1;
    public Label label_no_id1;
    public Button submit_button;
    public CheckBox red_blood_cell_box1;
    public CheckBox White_blood_cell_box1;
    public CheckBox Liver_function_test_box1;
    public CheckBox Renal_function_test_box1;
    public CheckBox Electrolyte_test_box1;
    public CheckBox X_rays_box1;
    public CheckBox Urinary_Test_box1;
    public CheckBox MRI_scans_box1;
    public CheckBox CT_scans_box1;
    public CheckBox Stool_Test_box1;
    public CheckBox Intramuscular_injection_box1;
    public CheckBox P_box1;
    public CheckBox Subcutaneous_injection_box1;
    public CheckBox Intravascular_injection_box1;
    public TextArea doctor_notes1;
    public Label user_name;
    public Button logout_button;

    public void logout(javafx.event.ActionEvent actionEvent) throws Exception{
        Parent root;
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout_button.getScene().getWindow();
        window.setScene(new Scene(root, 800,600));
    }

    public void search_button(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        if (patient_id.getText().isEmpty()) {
            label_no_id.setText("The field cannot be left blank. You must enter an ID");
        }

        else {
            String connectQuery = "SELECT * FROM patient_record WHERE patient_id = " + patient_id.getText() + ";";
            label_no_id.setText("");
            try {
                Statement statement = connect.createStatement();
                ResultSet queryRes = statement.executeQuery(connectQuery);

                if(!queryRes.isBeforeFirst()){
                    label_no_id.setText("No patient with this ID found");
                }
                while (queryRes.next()) {
                    name.setText(queryRes.getString("name"));
                    dob.setText(queryRes.getString("dob"));
                    assigned_p.setText(queryRes.getString("assigned_physician"));
                    body_temp.setText(queryRes.getString("body_temp"));
                    blood_pressure.setText(queryRes.getString("blood_pressure"));
                    nights_stayed.setText(queryRes.getString("nights_stayed"));
                    height_feet.setText(queryRes.getString("height_feet"));
                    height_inches.setText(queryRes.getString("height_inches"));
                    weight.setText(queryRes.getString("weight"));
                    gender.setText(queryRes.getString("gender"));
                    religion.setText(queryRes.getString("religion"));
                    primary_p.setText(queryRes.getString("primary_physician"));
                    health_insurance.setText(queryRes.getString("health_insurance"));
                    first_shot.setText(queryRes.getString("covid_vaccine_date_1"));
                    second_shot.setText(queryRes.getString("covid_vaccine_date_2"));
                    checkin_date.setText(queryRes.getString("check_in_date"));
                    booster.setText(queryRes.getString("covid_vaccine_booster_date"));
                    allergies.setText(queryRes.getString("allergies"));
                    previous_medical_conditions.setText(queryRes.getString("previous_medical_conditions"));
                    previous_medication.setText(queryRes.getString("previous_medication"));
                    symptoms.setText(queryRes.getString("symptoms"));
                    notes.setText(queryRes.getString("nurse_notes"));
                    doctor_notes.setText(queryRes.getString("doctor_notes"));
                    covid_name.setValue(queryRes.getString("covid_vaccine_name"));
                    sexually_active.setValue(queryRes.getString("sexually_active"));
                    race.setValue(queryRes.getString("race"));
                    bloodtype.setValue(queryRes.getString("blood_type"));
                    pregnant.setValue(queryRes.getString("pregnant"));
                    admitted.setValue(queryRes.getString("admitted"));
                    diagnosis_box.setValue(queryRes.getString("diagnosis"));
                    //no need to set value for medication since there is a method that automatically sets the correct medication based on the diagnosis
                    HashMap<String, CheckBox> checkboxes = new HashMap<>();

                    checkboxes.put("Red blood cell", red_blood_cell_box);
                    checkboxes.put("White blood cell", White_blood_cell_box);
                    checkboxes.put("Liver function test", Liver_function_test_box);
                    checkboxes.put("Renal function test", Renal_function_test_box);
                    checkboxes.put("Electrolyte test", Electrolyte_test_box);
                    checkboxes.put("X-rays", X_rays_box);
                    checkboxes.put("CT scans", CT_scans_box);
                    checkboxes.put("MRI scans", MRI_scans_box);
                    checkboxes.put("Urinary Test", Urinary_Test_box);
                    checkboxes.put("Stool Test", Stool_Test_box);
                    checkboxes.put("Intramuscular injection (IM)", Intramuscular_injection_box);
                    checkboxes.put("Intravascular injection (IV)", Intravascular_injection_box);
                    checkboxes.put("Subcutaneous injection (SC)", Subcutaneous_injection_box);
                    checkboxes.put("P.O (Per Os)", P_box);

                    if (queryRes.getString("tests").equals("N/A") == false) {


                        String tests[] = queryRes.getString("tests").split(",");
                        for (int i = 0; i < tests.length; i++) {
                            checkboxes.get(tests[i]).setSelected(true);
                        }
                    }
                    else{
                        for (Map.Entry<String, CheckBox> clear :
                                checkboxes.entrySet()) {
                            clear.getValue().setSelected(false);
                        }
                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        diagnosis_box.getItems().addAll("Covid-19", "Asthma", "Diabetes", "Hypertension", "Pneumonia", "Heart Attack");
        medication_box.getItems().addAll("Acetaminophen", "Albuterol", "Insulin", "Benazepril", "Clarithromycin", "Aspirin");
        diagnosis_box1.getItems().addAll("Covid-19", "Asthma", "Diabetes", "Hypertension", "Pneumonia", "Heart Attack");
        medication_box1.getItems().addAll("Acetaminophen", "Albuterol", "Insulin", "Benazepril", "Clarithromycin", "Aspirin");
        String user_name_query = "SELECT name FROM user_accounts WHERE user_id = " + LoginController.userID  + ";";
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(user_name_query);

            queryRes.next();

            user_name.setText(queryRes.getString("name"));

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public void diagnosis_medication_match() {
        if(diagnosis_box.getValue().equals("N/A")){
            medication_box.setValue("N/A");
        }
        if(diagnosis_box.getValue().equals("Covid-19")){
           medication_box.setValue("Acetaminophen");
       }

       else if (diagnosis_box.getValue().equals("Asthma")){
            medication_box.setValue("Albuterol");
       }

       else if(diagnosis_box.getValue().equals("Diabetes")){
            medication_box.setValue("Insulin");
       }

       else if(diagnosis_box.getValue().equals("Hypertension")){
            medication_box.setValue("Benazepril");
       }

       else if(diagnosis_box.getValue().equals("Pneumonia")){
            medication_box.setValue("Clarithromycin");
       }

       else if(diagnosis_box.getValue().equals("Heart Attack")){
            medication_box.setValue("Aspirin");
       }

    }

    public void discharge_diagnosis_medication_match() {
        if(diagnosis_box1.getValue().equals("N/A")){
            medication_box1.setValue("N/A");
        }
        if(diagnosis_box1.getValue().equals("Covid-19")){
            medication_box1.setValue("Acetaminophen");
        }

        else if (diagnosis_box1.getValue().equals("Asthma")){
            medication_box1.setValue("Albuterol");
        }

        else if(diagnosis_box1.getValue().equals("Diabetes")){
            medication_box1.setValue("Insulin");
        }

        else if(diagnosis_box1.getValue().equals("Hypertension")){
            medication_box1.setValue("Benazepril");
        }

        else if(diagnosis_box1.getValue().equals("Pneumonia")){
            medication_box1.setValue("Clarithromycin");
        }

        else if(diagnosis_box1.getValue().equals("Heart Attack")){
            medication_box1.setValue("Aspirin");
        }

    }


    public void update_button(javafx.event.ActionEvent actionEvent) {

        if (patient_id.getText().isEmpty()) {
            return;
        }
        String updated_tests = "";
        CheckBox[] checkboxss = new CheckBox[]{
                red_blood_cell_box, White_blood_cell_box, Liver_function_test_box, Renal_function_test_box,
                Electrolyte_test_box, X_rays_box, CT_scans_box, MRI_scans_box, Urinary_Test_box, Stool_Test_box,
                Intramuscular_injection_box, Intravascular_injection_box, Subcutaneous_injection_box, P_box
        };

        HashMap<CheckBox, String> checkboxes_update = new HashMap<>();

        checkboxes_update.put(red_blood_cell_box, "Red blood cell");
        checkboxes_update.put(White_blood_cell_box, "White blood cell");
        checkboxes_update.put(Liver_function_test_box, "Liver function test");
        checkboxes_update.put(Renal_function_test_box, "Renal function test");
        checkboxes_update.put(Electrolyte_test_box, "Electrolyte test");
        checkboxes_update.put(X_rays_box, "X-rays");
        checkboxes_update.put(CT_scans_box, "CT scans");
        checkboxes_update.put(MRI_scans_box, "MRI scans");
        checkboxes_update.put(Urinary_Test_box, "Urinary Test");
        checkboxes_update.put(Stool_Test_box, "Stool Test");
        checkboxes_update.put(Intramuscular_injection_box, "Intramuscular injection (IM)");
        checkboxes_update.put(Intravascular_injection_box, "Intravascular injection (IV)");
        checkboxes_update.put(Subcutaneous_injection_box, "Subcutaneous injection (SC)");
        checkboxes_update.put(P_box, "P.O (Per Os)");

        for(int k=0; k < checkboxss.length; k++){
            if(checkboxss[k].isSelected() == true){
                if(k == checkboxss.length -1){
                    updated_tests += checkboxes_update.get(checkboxss[k]);
                }
                else{
                    updated_tests += checkboxes_update.get(checkboxss[k]) + ",";
                }

            }
        }
        String update_query = "UPDATE patient_record SET diagnosis = '" + diagnosis_box.getValue() +  "', medication = '"
                + medication_box.getValue() + "', doctor_notes = '" + doctor_notes.getText() + "', tests = '"
                + updated_tests + "' WHERE patient_id = " + patient_id.getText() + ";";

        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        try {
            Statement st = connect.createStatement();
            st.executeUpdate(update_query);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            //alert.setHeaderText("This is header text.");
            alert.setContentText("Successfully updated the information for patient with ID: " + patient_id.getText());
            alert.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void add_button(javafx.event.ActionEvent actionEvent) {
        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        if (patient_id1.getText().isEmpty()) {
            label_no_id1.setText("The field cannot be left blank. You must enter an ID");
        }

        else {
            String connectQuery = "SELECT * FROM patient_record WHERE patient_id = " + patient_id1.getText() + ";";
            label_no_id1.setText("");
            try {
                Statement statement = connect.createStatement();
                ResultSet queryRes = statement.executeQuery(connectQuery);

                if (!queryRes.isBeforeFirst()) {
                    label_no_id1.setText("No patient with this ID found");
                }

                while (queryRes.next()) {
                    doctor_notes1.setText(queryRes.getString("doctor_notes"));
                    diagnosis_box1.setValue(queryRes.getString("diagnosis"));
                    //no need to set value for medication since there is a method that automatically sets the correct medication based on the diagnosis

                    HashMap<String, CheckBox> checkboxes = new HashMap<>();

                    checkboxes.put("Red blood cell", red_blood_cell_box1);
                    checkboxes.put("White blood cell", White_blood_cell_box1);
                    checkboxes.put("Liver function test", Liver_function_test_box1);
                    checkboxes.put("Renal function test", Renal_function_test_box1);
                    checkboxes.put("Electrolyte test", Electrolyte_test_box1);
                    checkboxes.put("X-rays", X_rays_box1);
                    checkboxes.put("CT scans", CT_scans_box1);
                    checkboxes.put("MRI scans", MRI_scans_box1);
                    checkboxes.put("Urinary Test", Urinary_Test_box1);
                    checkboxes.put("Stool Test", Stool_Test_box1);
                    checkboxes.put("Intramuscular injection (IM)", Intramuscular_injection_box1);
                    checkboxes.put("Intravascular injection (IV)", Intravascular_injection_box1);
                    checkboxes.put("Subcutaneous injection (SC)", Subcutaneous_injection_box1);
                    checkboxes.put("P.O (Per Os)", P_box1);

                    if (queryRes.getString("tests").equals("N/A") == false) {
                        String tests[] = queryRes.getString("tests").split(",");

                        for (Map.Entry<String, CheckBox> clear :
                                checkboxes.entrySet()) {
                            clear.getValue().setSelected(false);
                        }

                        for (String test : tests) {
                            checkboxes.get(test).setSelected(true);
                        }
                    }

                    else{
                        for (Map.Entry<String, CheckBox> clear :
                                checkboxes.entrySet()) {
                            clear.getValue().setSelected(false);
                        }

                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void submit_info(javafx.event.ActionEvent actionEvent) {

        if (patient_id1.getText().isEmpty()) {
            return;
        }

        DatabaseConnection connect_db = new DatabaseConnection();
        Connection connect = connect_db.getConnection();

        String connectQuery = "SELECT discharge_submitted FROM patient_record WHERE patient_id = " + patient_id1.getText() + ";";
        try {
            Statement statement = connect.createStatement();
            ResultSet queryRes = statement.executeQuery(connectQuery);

            queryRes.next();

            if (queryRes.getString("discharge_submitted").equals("yes")) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                //alert.setHeaderText("This is header text.");
                alert.setContentText("Discharge Info has been already submitted for this patient");
                alert.showAndWait();
            }

            else if (queryRes.getString("discharge_submitted").equals("no")) {

                String updated_tests = "";
                CheckBox[] checkboxss = new CheckBox[]{
                        red_blood_cell_box1, White_blood_cell_box1, Liver_function_test_box1, Renal_function_test_box1,
                        Electrolyte_test_box1, X_rays_box1, CT_scans_box1, MRI_scans_box1, Urinary_Test_box1, Stool_Test_box1,
                        Intramuscular_injection_box1, Intravascular_injection_box1, Subcutaneous_injection_box1, P_box1
                };

                HashMap<CheckBox, String> checkboxes_update = new HashMap<>();

                checkboxes_update.put(red_blood_cell_box1, "Red blood cell");
                checkboxes_update.put(White_blood_cell_box1, "White blood cell");
                checkboxes_update.put(Liver_function_test_box1, "Liver function test");
                checkboxes_update.put(Renal_function_test_box1, "Renal function test");
                checkboxes_update.put(Electrolyte_test_box1, "Electrolyte test");
                checkboxes_update.put(X_rays_box1, "X-rays");
                checkboxes_update.put(CT_scans_box1, "CT scans");
                checkboxes_update.put(MRI_scans_box1, "MRI scans");
                checkboxes_update.put(Urinary_Test_box1, "Urinary Test");
                checkboxes_update.put(Stool_Test_box1, "Stool Test");
                checkboxes_update.put(Intramuscular_injection_box1, "Intramuscular injection (IM)");
                checkboxes_update.put(Intravascular_injection_box1, "Intravascular injection (IV)");
                checkboxes_update.put(Subcutaneous_injection_box1, "Subcutaneous injection (SC)");
                checkboxes_update.put(P_box1, "P.O (Per Os)");

                for (int k = 0; k < checkboxss.length; k++) {
                    if (checkboxss[k].isSelected() == true) {
                        if (k == checkboxss.length - 1) {
                            updated_tests += checkboxes_update.get(checkboxss[k]);
                        } else {
                            updated_tests += checkboxes_update.get(checkboxss[k]) + ",";
                        }

                    }
                }
                String update_query = "UPDATE patient_record SET diagnosis = '" + diagnosis_box1.getValue() + "', medication = '"
                        + medication_box1.getValue() + "', doctor_notes = '" + doctor_notes.getText() + "', tests = '"
                        + updated_tests + "', discharge_submitted = 'yes' WHERE patient_id = " + patient_id1.getText() + ";";


                try {
                    Statement st = connect.createStatement();
                    st.executeUpdate(update_query);

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Discharge Info has been successfully submitted for patient with ID: " + patient_id1.getText());
                    alert.showAndWait();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }catch(Exception e){
                e.printStackTrace();
            }
        }
}
