package com.example.login;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.fxml.Initializable;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    public static String userID;

    @FXML
    private Button exitButton, loginButton;
    @FXML
    private Label loginMessageLabel, noTypeSelectedLabel;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordPasswordField;
    @FXML
    private ComboBox userTypeBox;

    public void loginButtonOnAction(ActionEvent e){


        if (usernameField.getText().isBlank() == false && passwordPasswordField.getText().isBlank() == false){
            //loginMessageLabel.setText("Error: Unrecognized Credentials");

            validateLogin();

        } else {
            loginMessageLabel.setText("Please enter a username and password.");
        }
    }

    public void exitButtonOnAction(ActionEvent e) {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }

    public void validateLogin() {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String verifyLogin = "SELECT count(1) FROM user_accounts WHERE username = '" + usernameField.getText()
                + "' AND password = '" + passwordPasswordField.getText() + "' AND user_type ='"
                + userTypeBox.getValue() + "'";

        try {

            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyLogin);

            while (queryResult.next()){
                if (queryResult.getInt(1) == 1) {
                    userID = getID();
                    switchPage();
                } else {
                    loginMessageLabel.setText("Invalid login. Please try again.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getID() throws SQLException {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String userIDQuery = "SELECT user_id FROM user_accounts WHERE username = '" + usernameField.getText()
                + "' AND password = '" + passwordPasswordField.getText() + "'";
        Statement statement = connectDB.createStatement();
        ResultSet queryResult = statement.executeQuery(userIDQuery);
        queryResult.next();
        return queryResult.getString("user_id");
    }

    public void initialize(URL url, ResourceBundle rb) {
        userTypeBox.getItems().addAll("Registrar","Nurse","Doctor","Billing","Patient");
    }

    public void switchPage() throws Exception {
        Parent root;

        if (userTypeBox.getValue() == null) {
            noTypeSelectedLabel.setText("Please select a user type.");
        } else if(userTypeBox.getValue().equals("Billing")) {
            root = FXMLLoader.load(getClass().getResource("billing.fxml"));
            Stage window = (Stage) loginButton.getScene().getWindow();
            window.setScene(new Scene(root, 800,600));
        } else if (userTypeBox.getValue().equals("Doctor")) {
            root = FXMLLoader.load(getClass().getResource("doctor.fxml"));
            Stage window = (Stage) loginButton.getScene().getWindow();
            window.setScene(new Scene(root, 800,600));
        } else if (userTypeBox.getValue().equals("Patient")) {
            root = FXMLLoader.load(getClass().getResource("patient.fxml"));
            Stage window = (Stage) loginButton.getScene().getWindow();
            window.setScene(new Scene(root, 800,600));
        } else if (userTypeBox.getValue().equals("Nurse")) {
            root = FXMLLoader.load(getClass().getResource("nurse.fxml"));
            Stage window = (Stage) loginButton.getScene().getWindow();
            window.setScene(new Scene(root, 800,600));
        } else if (userTypeBox.getValue().equals("Registrar")) {
            root = FXMLLoader.load(getClass().getResource("registrar.fxml"));
            Stage window = (Stage) loginButton.getScene().getWindow();
            window.setScene(new Scene(root, 800,600));
        }

    }
}
